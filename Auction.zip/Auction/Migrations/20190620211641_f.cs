﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Auction.Migrations
{
    public partial class f : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<decimal>(
                name: "Wallet",
                table: "Users",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AlterColumn<decimal>(
                name: "Bid",
                table: "Auctions",
                nullable: false,
                oldClrType: typeof(double));

            migrationBuilder.AddColumn<int>(
                name: "BidderId",
                table: "Auctions",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "DaysRemaining",
                table: "Auctions",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Wallet",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "BidderId",
                table: "Auctions");

            migrationBuilder.DropColumn(
                name: "DaysRemaining",
                table: "Auctions");

            migrationBuilder.AlterColumn<double>(
                name: "Bid",
                table: "Auctions",
                nullable: false,
                oldClrType: typeof(decimal));
        }
    }
}
