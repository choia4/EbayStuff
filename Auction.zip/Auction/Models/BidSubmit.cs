using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

namespace Auction.Models {

    public class BidSubmit
    {
        public int Auction_Id { get; set; }

        public Decimal CurrBid {get;set;}

        [Required]
        public Decimal NewBid {get;set;}

        public DateTime Created_At { get; set; } = DateTime.Now;
        public DateTime Updated_At { get; set; } = DateTime.Now;



    }
}