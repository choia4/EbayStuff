using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class LoginUser
{

    [Required]
    [MinLength(4, ErrorMessage = "User Name must be greater than 3")]
    [MaxLength(19, ErrorMessage = "User Name must be less than 20")]
    [Display(Name = "Username")]
    public string Username2 { get; set; }

    [DataType(DataType.Password)]
    [Required]
    [Display(Name = "Password")]
    [MinLength(8, ErrorMessage = "Password must be 8 characters or longer!")]
    public string Password2 { get; set; }
}
