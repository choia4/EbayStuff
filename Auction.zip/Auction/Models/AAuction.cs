using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

namespace Auction.Models
{
    public class AAuction
    {
        [Key]
        public int AuctionId { get; set; }

        [Required]
        [MinLength(4, ErrorMessage = "Product name must be greater than 3 characters")]
        public string Name {get;set;}

        [Required]
        [MinLength(11, ErrorMessage = "Product description must be greater than 10 characters")]
        public string Description{get;set;}

        [Required]
        [Range(0.0, Double.MaxValue)]
        public Decimal Bid {get;set;}
        
        public int BidderId {get;set;}

        [Required]
        public DateTime EndDate{get;set;}

        public int DaysRemaining{get;set;}
        
        public int UserId {get;set;}
        public User User {get;set;}

        public DateTime Created_At {get;set;} = DateTime.Now;
        public DateTime Updated_At {get;set;} = DateTime.Now;



    }
}