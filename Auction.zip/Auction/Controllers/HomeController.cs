﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
using Auction.Models;

namespace Auction.Controllers
{
    public class HomeController : Controller
    {
        MyContext dbContext;

        public HomeController(MyContext context)
        {
            dbContext = context;
        }


        [HttpPost("registration")]
        public IActionResult Registration(User newUser)
        {
            if (ModelState.IsValid)
            {
                //Check if email already exists
                var userInDb = dbContext.Users.FirstOrDefault(u => u.Username == newUser.Username);
                if (userInDb != null)
                {
                    ModelState.AddModelError("Username", "Account Already Exists");
                    return View("Index");
                }

                // Initializing a PasswordHasher object, providing our User class as its
                PasswordHasher<User> Hasher = new PasswordHasher<User>();
                newUser.Password = Hasher.HashPassword(newUser, newUser.Password);

                newUser.Wallet = 1000;

                dbContext.Add(newUser);
                dbContext.SaveChanges();

                //query the user to get their new user Id
                var this_user = dbContext.Users.FirstOrDefault(u => u.Username == newUser.Username);

                HttpContext.Session.SetString("First_Name", this_user.First_Name);
                HttpContext.Session.SetString("Last_Name", this_user.Last_Name);
                HttpContext.Session.SetInt32("User_Id", this_user.UserId);

                return RedirectToAction("Dashboard");
            }
            else
            {
                return View("Index");
            }
        }

        [HttpPost("loginval")]
        public IActionResult LoginVal(LoginUser user)
        {
            if (ModelState.IsValid)
            {
                // If inital ModelState is valid, query for a user with provided email
                var userInDb = dbContext.Users.FirstOrDefault(u => u.Username == user.Username2);
                // If no user exists with provided email
                if (userInDb == null)
                {
                    // Add an error to ModelState and return to View!
                    ModelState.AddModelError("Username2", "Invalid Username");
                    return View("Index");
                }

                // Initialize hasher object
                var hasher = new PasswordHasher<LoginUser>();

                var result = hasher.VerifyHashedPassword(user, userInDb.Password, user.Password2);

                // result can be compared to 0 for failure
                if (result == 0)
                {
                    ModelState.AddModelError("Password2", "Invalid Username/Password");
                    return View("Index");
                }

                //instantiate session variables
                HttpContext.Session.SetString("First_Name", userInDb.First_Name);
                HttpContext.Session.SetString("Last_Name", userInDb.Last_Name);
                HttpContext.Session.SetInt32("User_Id", userInDb.UserId);
                return RedirectToAction("Dashboard");

            }
            else
            {
                return View("Index");
            }
        }


        [Route("")]
        [HttpGet]
        public IActionResult Index()
        {
            if (HttpContext.Session.GetInt32("User_Id") != null)
                return RedirectToAction("Dashboard");
            return View();
        }

        [Route("login")]
        [HttpGet]
        public IActionResult Login()
        {
            if (HttpContext.Session.GetInt32("User_Id") != null)
                return RedirectToAction("Dashboard");
            return View();
        }

        [Route("Dashboard")]
        [HttpGet]
        public IActionResult Dashboard()
        {   
            int? M_User_Id = HttpContext.Session.GetInt32("User_Id");
            if (M_User_Id == null)
                return RedirectToAction("Index");
            int User_Id = (int) M_User_Id;
            User user = dbContext.Users
                .Include(a => a.Auctions)
                .FirstOrDefault(u => u.UserId == User_Id);
            if(user == null) {
                return RedirectToAction("Index");
            }
            ViewBag.User = user;
            List<AAuction> AAuctions = dbContext.Auctions
                .Include(u => u.User)
                .ToList();

            foreach(AAuction auction in AAuctions) {
                int dayDiff = (auction.EndDate - DateTime.Now).Days;
                if(dayDiff != auction.DaysRemaining)
                    auction.DaysRemaining = dayDiff;

                if(auction.DaysRemaining < 0) {
                    User u = dbContext.Users
                            .Include(a => a.Auctions)
                            .FirstOrDefault(v => v.UserId == auction.BidderId);
                    if(!(u.Wallet - auction.Bid < 0) && auction.BidderId != 0) {
                        auction.User.Wallet += auction.Bid;
                        u.Wallet -= auction.Bid;

                        dbContext.Remove(auction);
                        dbContext.SaveChanges();
                    }
                }
            }
            
            dbContext.SaveChanges();

            List<AAuction> ordered = AAuctions.OrderBy(d => d.DaysRemaining).ToList();
            return View(ordered);
        }

        [Route("AddAuction")]
        [HttpGet]
        public IActionResult AddAuction() {
            int? M_User_Id = HttpContext.Session.GetInt32("User_Id");
            if (M_User_Id == null)
                return RedirectToAction("Index");
            int User_Id = (int)M_User_Id;
            return View();
        }

        [HttpPost("CreateAuction")]
        public IActionResult CreateAuction(AAuction a) {
            int? M_User_Id = HttpContext.Session.GetInt32("User_Id");
            if (M_User_Id == null)
                return RedirectToAction("Index");
            int User_Id = (int)M_User_Id;
            if(ModelState.IsValid) {
                if( a.Bid <= 0)
                    ModelState.AddModelError("Bid", "Bid cannot be less than or equal to 0$");
                if((a.EndDate - DateTime.Now).Days < 0) {
                    ModelState.AddModelError("EndDate", "Bid cannot be made in the past");
                }
                User user = dbContext.Users.Include(s => s.Auctions).FirstOrDefault(u => u.UserId == User_Id);
                a.DaysRemaining = (a.EndDate - DateTime.Now).Days;
                a.BidderId = 0;
                a.UserId = User_Id;
                dbContext.Add(a);
                dbContext.SaveChanges();
                return RedirectToAction("DashBoard");

            } else {
                return View("AddAuction");
            }
        }

        [Route("Delete/{Auction_Id}")]
        [HttpGet]
        public IActionResult Delete(int Auction_Id) {
            int? M_User_Id = HttpContext.Session.GetInt32("User_Id");
            if (M_User_Id == null)
                return RedirectToAction("Index");
            int User_Id = (int)M_User_Id;
            AAuction auction = dbContext.Auctions
                .Include(u => u.User)
                .FirstOrDefault(a => a.AuctionId == Auction_Id);
                dbContext.Remove(auction);
                dbContext.SaveChanges();
                return RedirectToAction("Dashboard");
        }

        [Route("Description/{Auction_Id}")]
        [HttpGet]
        public IActionResult Description(int Auction_Id) {
            int? M_User_Id = HttpContext.Session.GetInt32("User_Id");
            if (M_User_Id == null)
                return RedirectToAction("Index");
            int User_Id = (int) M_User_Id;
            AAuction auction = dbContext.Auctions
                .Include(u => u.User)
                .FirstOrDefault(a => a.AuctionId == Auction_Id);

                ViewBag.User = dbContext.Users
                .Include(a => a.Auctions)
                .FirstOrDefault(u => u.UserId == auction.BidderId);

                return View("Description", auction);
            
        }

        [Route("Description")]
        [HttpGet]
        public IActionResult Description() {
            int? M_User_Id = HttpContext.Session.GetInt32("User_Id");
            if (M_User_Id == null)
                return RedirectToAction("Index");
            int User_Id = (int)M_User_Id;
            int Auction_Id = (int) TempData["Auction_Id"];
            AAuction auction = dbContext.Auctions
                .Include(u => u.User)
                .FirstOrDefault(a => a.AuctionId == Auction_Id);

            ViewBag.User = dbContext.Users
                .Include(a => a.Auctions)
                .FirstOrDefault(u => u.UserId == auction.BidderId);
            return View("Description", auction);
        }

        [Route("logout")]
        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");

        }

        [HttpPost]
        [Route("Description/method")]
        public IActionResult Method(Decimal NewBid, Decimal CurrBid, int Auction_Id) {
            int? M_User_Id = HttpContext.Session.GetInt32("User_Id");
            if (M_User_Id == null)
                return RedirectToAction("Index");
            int User_Id = (int)M_User_Id;
            User user = dbContext.Users
                .Include(u => u.Auctions)
                .FirstOrDefault(u =>u.UserId == User_Id);
            AAuction auction = dbContext.Auctions
                .Include(u => u.User)
                .FirstOrDefault(a => a.AuctionId == Auction_Id);
            ViewBag.User = dbContext.Users
                .Include(a => a.Auctions)
                .FirstOrDefault(u => u.UserId == auction.BidderId);
            if(NewBid <= 0) {
                ModelState.AddModelError("NewBid", "New bid must be greater than 0");
                return View("Description", auction);
            }
            else if( NewBid <= CurrBid) {
                ModelState.AddModelError("NewBid", "New bid must be greater than the old one");
                return View("Description", auction);
            } else if(user.Wallet < NewBid) {
                ModelState.AddModelError("NewBid", "Insufficient funds");
                return View("Description", auction);
            }

            Decimal total = 0;
            foreach(AAuction a in user.Auctions) {
                if(a.BidderId == User_Id) {
                    total += a.Bid;
                }
            }

            if(total + NewBid > user.Wallet) {
                ModelState.AddModelError("NewBid", "You have too many investments in other bids that overdraw your wallet");
                TempData["Auction_Id"] = Auction_Id;
                return View("Description");
            }

            auction.BidderId = user.UserId;
            auction.Bid = NewBid;
            dbContext.SaveChanges();

            return RedirectToAction("Dashboard");
            


            




        }

    }
}
